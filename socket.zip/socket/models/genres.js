var mongoose = require('mongoose');
 
module.exports = mongoose.model('Genres',{
    genres: String
});