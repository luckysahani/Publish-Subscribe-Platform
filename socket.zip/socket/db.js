module.exports = {
  'url' : 'mongodb://localhost/assignment3_1'
}